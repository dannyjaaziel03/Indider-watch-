# Solana Insider Watch — iOS

Native SwiftUI iPhone app project for monitoring public Solana token market signals.

## Included
- Preloaded Solana watchlist from the previous mobile build
- Live DEX Screener market data
- BUY WATCH / NEUTRAL / HIGH RISK scoring
- 5-minute price, buys/sells, volume, liquidity, and market cap
- Liquidity-drop detection using the previous in-app scan
- Add/remove token addresses
- 60-second auto refresh while the app is active
- Pull-to-refresh
- Local notifications when a token changes into BUY WATCH or HIGH RISK while the app is active
- App icon set and App Store-ready Xcode project structure

## Open and run
1. On a Mac, install the latest Xcode supported by Apple.
2. Open `SolanaInsiderWatch.xcodeproj`.
3. Select the `SolanaInsiderWatch` project > `Signing & Capabilities`.
4. Choose your Apple Developer Team.
5. Change the bundle identifier from `com.example.SolanaInsiderWatch` to a unique identifier you own, for example `com.yourcompany.insiderwatch`.
6. Select an iPhone or simulator and press Run.

## TestFlight / App Store
1. In Xcode, set a unique bundle identifier and your Developer Team.
2. Product > Archive.
3. In Organizer, choose Distribute App > App Store Connect > Upload.
4. In App Store Connect, create/finish the app record, add screenshots, privacy information, support/privacy-policy URLs, age rating, and review notes.
5. Add the uploaded build to a TestFlight group first, then submit the desired build to App Review.

## Important limitation
This v1 iOS build performs refreshes while the app is active. iOS may suspend it in the background. Reliable alerts while the app is closed require a hosted backend plus Apple Push Notification service (APNs). No wallet private keys, seed phrases, or trade execution are used in this build.

## App-review positioning
Describe the app as a public blockchain/market-data monitoring tool. `BUY WATCH` is a custom indicator, not a promise of returns and not proof of illegal insider activity. Consider using a neutral App Store subtitle such as “Solana Market Signal Monitor.”

## Data source
The app uses DEX Screener's public HTTPS token-pair endpoint. If the provider changes its API or rate limits, the service implementation may need updating.
